package com.example.myhealth

import androidx.activity.compose.setContent
import com.example.myhealth.ui.theme.MyHealthTheme
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.firestore.FirebaseFirestore
import android.util.Log
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.crashlytics.FirebaseCrashlytics


class MainActivity : ComponentActivity() {
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        firebaseAnalytics = FirebaseAnalytics.getInstance(this)


        val bundle = Bundle().apply {
            putString(FirebaseAnalytics.Param.METHOD, "compose_app_start")
        }
        firebaseAnalytics.logEvent(FirebaseAnalytics.Event.APP_OPEN, bundle)


        setContent {
            MyHealthTheme {
                MainScreen()
            }
        }
    }
}
@Composable
fun MainScreen() {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Welcome to MyHealth",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val intent = Intent(context, WorkoutTrackerActivity::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text("Go to Workout Tracker")
        }

        Button(
            onClick = {
                val intent = Intent(context, MealPlannerActivity::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text("Go to Meal Planner")
        }
    }
}

fun triggerCrash() {
    FirebaseCrashlytics.getInstance().log("Test crash triggered")
    throw RuntimeException("This is a test crash")
}


fun writeUserData() {
    val db = FirebaseFirestore.getInstance()
    val user = hashMapOf(
        "first" to "Lamar",
        "last" to "Feidi",
        "born" to 1999
    )

    db.collection("users")
        .add(user)
        .addOnSuccessListener { documentRef ->
            Log.d("Firestore", "DocumentSnapshot added with ID: ${documentRef.id}")
        }
        .addOnFailureListener { e ->
            Log.w("Firestore", "Error adding document", e)
        }
}


fun readUsers() {
    val db = FirebaseFirestore.getInstance()
    db.collection("users")
        .get()
        .addOnSuccessListener { result ->
            for (document in result) {
                Log.d("Firestore", "${document.id} => ${document.data}")
            }
        }
        .addOnFailureListener { exception ->
            Log.w("Firestore", "Error getting documents.", exception)
        }
}
