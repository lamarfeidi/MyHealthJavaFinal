package com.example.myhealth
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.widget.EditText
import com.example.myhealth.ui.theme.MyHealthTheme

class MealPlannerActivity : ComponentActivity() {
    private lateinit var mealAdapter: MealAdapter
    private val mealList = mutableListOf("Grilled Chicken Salad", "Oatmeal with Fruits", "Avocado Toast")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_planner)

        val recyclerView = findViewById<RecyclerView>(R.id.mealRecyclerView)
        val addMealButton = findViewById<Button>(R.id.addMealButton)
        val mealInput = findViewById<EditText>(R.id.mealInput)

        mealAdapter = MealAdapter(mealList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = mealAdapter

        addMealButton.setOnClickListener {
            val newMeal = mealInput.text.toString()
            if (newMeal.isNotBlank()) {
                mealList.add(newMeal)
                mealAdapter.notifyItemInserted(mealList.size - 1)
                mealInput.text.clear()
            }
        }
    }
}

