package com.example.myhealth
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.widget.EditText
import androidx.core.content.ContextCompat
import com.example.myhealth.R
import androidx.recyclerview.widget.ItemTouchHelper.SimpleCallback

class WorkoutTrackerActivity : ComponentActivity() {
    private lateinit var workoutAdapter: WorkoutAdapter
    private val workoutList = mutableListOf("Push-ups", "Squats", "Jumping Jacks")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workout_tracker)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val addWorkoutButton = findViewById<Button>(R.id.addWorkoutButton)
        val workoutInput = findViewById<EditText>(R.id.workoutInput)

        workoutAdapter = WorkoutAdapter(workoutList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = workoutAdapter

        addWorkoutButton.setOnClickListener {
            val newWorkout = workoutInput.text.toString()
            if (newWorkout.isNotBlank()) {
                workoutList.add(newWorkout)
                workoutAdapter.notifyItemInserted(workoutList.size - 1)
                workoutInput.text.clear()
            }
        }

        // Add swipe-to-delete functionality
        val itemTouchHelper = ItemTouchHelper(object : SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    workoutList.removeAt(position)
                    workoutAdapter.notifyItemRemoved(position)
                }
                workoutList.removeAt(position)
                workoutAdapter.notifyItemRemoved(position)
            }
        })
        itemTouchHelper.attachToRecyclerView(recyclerView)
    }
}


